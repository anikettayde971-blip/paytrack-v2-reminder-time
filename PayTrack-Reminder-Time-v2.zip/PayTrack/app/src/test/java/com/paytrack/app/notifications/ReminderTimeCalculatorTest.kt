package com.paytrack.app.notifications

import org.junit.Assert.assertEquals
import org.junit.Test
import java.util.Calendar

class ReminderTimeCalculatorTest {
    private fun date(year: Int, month: Int, day: Int, hour: Int = 9, minute: Int = 0): Long =
        Calendar.getInstance().apply {
            clear()
            set(year, month - 1, day, hour, minute, 0)
        }.timeInMillis

    private fun parts(value: Long): List<Int> = Calendar.getInstance().apply { timeInMillis = value }.let {
        listOf(it.get(Calendar.YEAR), it.get(Calendar.MONTH) + 1, it.get(Calendar.DAY_OF_MONTH), it.get(Calendar.HOUR_OF_DAY), it.get(Calendar.MINUTE))
    }

    @Test fun dueAndTwoDayWarningUseChosenTime() {
        val due = date(2026, 11, 15, 9, 0)
        assertEquals(listOf(2026, 11, 15, 18, 45), parts(ReminderTimeCalculator.atTime(due, 18, 45)))
        assertEquals(listOf(2026, 11, 13, 18, 45), parts(ReminderTimeCalculator.daysBefore(due, 2, 18, 45)))
    }

    @Test fun firstPendingIsDayAfterDueAtSelectedTime() {
        val due = date(2026, 11, 15)
        val now = date(2026, 11, 14, 12)
        assertEquals(listOf(2026, 11, 16, 7, 30), parts(ReminderTimeCalculator.firstPending(due, now, 7, 30)))
    }

    @Test fun overdueInvestmentGetsNextSelectedTimeNotImmediateAlarm() {
        val due = date(2026, 11, 10, 9)
        val now = date(2026, 11, 12, 6)
        assertEquals(listOf(2026, 11, 12, 7, 30), parts(ReminderTimeCalculator.firstPending(due, now, 7, 30)))
    }

    @Test fun pendingRepeatsTomorrowAtSameTime() {
        val now = date(2026, 11, 15, 18, 45)
        assertEquals(listOf(2026, 11, 16, 8, 15), parts(ReminderTimeCalculator.nextDay(now, 8, 15)))
    }
}
