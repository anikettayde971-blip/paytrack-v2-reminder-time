package com.paytrack.app.data

import org.junit.Assert.assertEquals
import org.junit.Test
import java.util.Calendar

class RecurrenceCalculatorTest {
    private fun date(year: Int, month: Int, day: Int): Long = Calendar.getInstance().apply {
        clear()
        set(year, month - 1, day, 9, 0, 0)
    }.timeInMillis

    private fun parts(timestamp: Long): Triple<Int, Int, Int> {
        val c = Calendar.getInstance().apply { timeInMillis = timestamp }
        return Triple(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    @Test fun monthlyKeepsThirtyFirstAcrossShortMonth() {
        val jan31 = date(2027, 1, 31)
        val feb = RecurrenceCalculator.advanceDue(jan31, "Monthly", 30, 31, 0)
        val mar = RecurrenceCalculator.advanceDue(feb, "Monthly", 30, 31, 0)
        assertEquals(Triple(2027, 2, 28), parts(feb))
        assertEquals(Triple(2027, 3, 31), parts(mar))
    }

    @Test fun quarterlyAdvancesThreeMonths() {
        val oct15 = date(2027, 10, 15)
        assertEquals(Triple(2028, 1, 15), parts(RecurrenceCalculator.advanceDue(oct15, "Quarterly", 30, 15, 9)))
    }

    @Test fun halfYearlyAdvancesSixMonths() {
        val nov10 = date(2027, 11, 10)
        assertEquals(Triple(2028, 5, 10), parts(RecurrenceCalculator.advanceDue(nov10, "Half-Yearly", 30, 10, 10)))
    }

    @Test fun yearlyLeapDayClampsAndReturnsToLeapDay() {
        val feb29 = date(2024, 2, 29)
        val feb28NextYear = RecurrenceCalculator.advanceDue(feb29, "Yearly", 30, 29, 1)
        val feb28FollowingYear = RecurrenceCalculator.advanceDue(feb28NextYear, "Yearly", 30, 29, 1)
        val feb28NonLeapYear = RecurrenceCalculator.advanceDue(feb28FollowingYear, "Yearly", 30, 29, 1)
        val feb29LeapYear = RecurrenceCalculator.advanceDue(feb28NonLeapYear, "Yearly", 30, 29, 1)
        assertEquals(Triple(2025, 2, 28), parts(feb28NextYear))
        assertEquals(Triple(2026, 2, 28), parts(feb28FollowingYear))
        assertEquals(Triple(2027, 2, 28), parts(feb28NonLeapYear))
        assertEquals(Triple(2028, 2, 29), parts(feb29LeapYear))
    }

    @Test fun customIntervalUsesRequestedNumberOfDays() {
        val start = date(2027, 4, 1)
        assertEquals(Triple(2027, 5, 16), parts(RecurrenceCalculator.advanceDue(start, "Custom", 45)))
    }

    @Test fun nextDueSkipsAllElapsedPeriods() {
        val start = date(2027, 1, 15)
        val now = date(2027, 4, 20)
        assertEquals(Triple(2027, 5, 15), parts(RecurrenceCalculator.nextDue(start, "Monthly", 30, now, 15, 0)))
    }
}
