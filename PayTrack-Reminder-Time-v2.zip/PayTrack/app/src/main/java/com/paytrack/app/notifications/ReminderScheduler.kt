package com.paytrack.app.notifications

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.paytrack.app.data.Investment
import com.paytrack.app.data.TaskItem
import com.paytrack.app.data.PayTrackDatabase
import androidx.room.Room
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object ReminderScheduler {
    private const val INVESTMENT_BASE = 100000
    private const val TASK_BASE = 500000

    fun scheduleInvestment(context: Context, item: Investment) {
        cancelInvestment(context, item.id)
        val hour = item.reminderHour.coerceIn(0, 23)
        val minute = item.reminderMinute.coerceIn(0, 59)
        val due = ReminderTimeCalculator.atTime(item.nextDue, hour, minute)
        val twoDaysBefore = ReminderTimeCalculator.daysBefore(item.nextDue, 2, hour, minute)
        val firstPending = ReminderTimeCalculator.firstPending(item.nextDue, System.currentTimeMillis(), hour, minute)
        schedule(context, INVESTMENT_BASE + item.id.toInt() * 10, twoDaysBefore, "investment", item.id, "two_days")
        schedule(context, INVESTMENT_BASE + item.id.toInt() * 10 + 1, due, "investment", item.id, "due")
        schedule(context, INVESTMENT_BASE + item.id.toInt() * 10 + 2, firstPending, "investment", item.id, "pending")
    }

    fun scheduleTask(context: Context, item: TaskItem) {
        cancelTask(context, item.id)
        schedule(context, TASK_BASE + item.id.toInt(), item.deadline - DAY, "task", item.id, "task")
    }

    fun scheduleNextPending(context: Context, item: Investment) {
        val next = ReminderTimeCalculator.nextDay(System.currentTimeMillis(), item.reminderHour, item.reminderMinute)
        schedule(context, INVESTMENT_BASE + item.id.toInt() * 10 + 2, next, "investment", item.id, "pending")
    }

    suspend fun rescheduleAll(context: Context) = withContext(Dispatchers.IO) {
        val db = Room.databaseBuilder(context, PayTrackDatabase::class.java, "paytrack.db")
            .addMigrations(PayTrackDatabase.MIGRATION_1_2, PayTrackDatabase.MIGRATION_2_3).build()
        try {
            db.dao().allInvestments().filter { it.active }.forEach { scheduleInvestment(context, it) }
            db.dao().allTasks().filter { !it.completed }.forEach { scheduleTask(context, it) }
        } finally {
            db.close()
        }
    }

    internal fun hasInvestmentAlarm(context: Context, id: Long, slot: Int): Boolean =
        hasAlarm(context, INVESTMENT_BASE + id.toInt() * 10 + slot)

    internal fun hasTaskAlarm(context: Context, id: Long): Boolean =
        hasAlarm(context, TASK_BASE + id.toInt())

    private fun hasAlarm(context: Context, requestCode: Int): Boolean {
        val intent = Intent(context, ReminderReceiver::class.java)
        return PendingIntent.getBroadcast(context, requestCode, intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE) != null
    }

    fun cancelInvestment(context: Context, id: Long) {
        for (i in 0..2) cancel(context, INVESTMENT_BASE + id.toInt() * 10 + i)
    }
    fun cancelTask(context: Context, id: Long) = cancel(context, TASK_BASE + id.toInt())

    private fun schedule(context: Context, requestCode: Int, at: Long, kind: String, id: Long, type: String) {
        if (at <= System.currentTimeMillis()) return
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra("kind", kind); putExtra("itemId", id); putExtra("type", type)
        }
        val pi = PendingIntent.getBroadcast(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarm.canScheduleExactAlarms()) {
            alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } else {
            alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    private fun cancel(context: Context, requestCode: Int) {
        val intent = Intent(context, ReminderReceiver::class.java)
        val pi = PendingIntent.getBroadcast(context, requestCode, intent, PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE) ?: return
        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi)
        pi.cancel()
    }
    const val DAY = 24L * 60L * 60L * 1000L
}
