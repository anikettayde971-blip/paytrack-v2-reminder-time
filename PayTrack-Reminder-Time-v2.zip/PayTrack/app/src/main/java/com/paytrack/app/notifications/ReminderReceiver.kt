package com.paytrack.app.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.room.Room
import com.paytrack.app.data.PayTrackDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val database = Room.databaseBuilder(context, PayTrackDatabase::class.java, "paytrack.db").addMigrations(PayTrackDatabase.MIGRATION_1_2, PayTrackDatabase.MIGRATION_2_3).build()
                val dao = database.dao()
                val id = intent.getLongExtra("itemId", -1L)
                val kind = intent.getStringExtra("kind") ?: "investment"
                val type = intent.getStringExtra("type") ?: "due"
                if (kind == "investment") {
                    val item = dao.investment(id)
                    if (item != null) {
                        val money = NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply { maximumFractionDigits = 0; minimumFractionDigits = 0 }.format(item.amount)
                        val body = when (type) {
                            "two_days" -> "You have to add $money to your ${item.name} in 2 days."
                            "pending" -> "Reminder! Your $money ${item.name} contribution is still pending."
                            else -> "Payment Due Today! Please add $money to your ${item.name}."
                        }
                        notify(context, (id * 10 + type.hashCode()).toInt(), item.name, body)
                        if (type == "due" || type == "pending") ReminderScheduler.scheduleNextPending(context, item)
                    }
                } else {
                    val task = dao.allTasks().firstOrNull { it.id == id && !it.completed }
                    if (task != null) notify(context, (500000 + id).toInt(), "Task reminder", "${task.title} is due tomorrow.")
                }
                database.close()
            } finally { pending.finish() }
        }
    }

    private fun notify(context: Context, id: Int, title: String, body: String) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel("paytrack_reminders", "PayTrack reminders", NotificationManager.IMPORTANCE_HIGH))
        val notification = NotificationCompat.Builder(context, "paytrack_reminders")
            .setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body)).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).build()
        try { NotificationManagerCompat.from(context).notify(id, notification) } catch (_: SecurityException) { }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                ReminderScheduler.rescheduleAll(context)
            } finally { pending.finish() }
        }
    }
}
