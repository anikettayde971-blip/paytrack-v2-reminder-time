package com.paytrack.app.data

import java.util.Calendar

/** Calendar-aware recurrence math. anchorDay/anchorMonth keep month-end schedules stable. */
object RecurrenceCalculator {
    fun advanceDue(
        from: Long,
        frequency: String,
        customDays: Int,
        anchorDay: Int = 0,
        anchorMonth: Int = -1
    ): Long {
        val calendar = Calendar.getInstance().apply { timeInMillis = from }
        if (frequency == "Custom") {
            calendar.add(Calendar.DAY_OF_YEAR, customDays.coerceAtLeast(1))
            return calendar.timeInMillis
        }

        val months = when (frequency) {
            "Monthly" -> 1
            "Quarterly" -> 3
            "Half-Yearly" -> 6
            else -> 12
        }
        calendar.set(Calendar.DAY_OF_MONTH, 1)
        calendar.add(Calendar.MONTH, months)
        if (frequency == "Yearly" && anchorMonth in Calendar.JANUARY..Calendar.DECEMBER) {
            calendar.set(Calendar.MONTH, anchorMonth)
        }
        val originalDay = Calendar.getInstance().apply { timeInMillis = from }.get(Calendar.DAY_OF_MONTH)
        val desiredDay = anchorDay.takeIf { it in 1..31 } ?: originalDay
        calendar.set(Calendar.DAY_OF_MONTH, minOf(desiredDay, calendar.getActualMaximum(Calendar.DAY_OF_MONTH)))
        return calendar.timeInMillis
    }

    fun nextDue(
        from: Long,
        frequency: String,
        customDays: Int,
        now: Long,
        anchorDay: Int = 0,
        anchorMonth: Int = -1
    ): Long {
        var next = advanceDue(from, frequency, customDays, anchorDay, anchorMonth)
        var guard = 0
        while (next <= now && guard++ < 10_000) {
            next = advanceDue(next, frequency, customDays, anchorDay, anchorMonth)
        }
        return next
    }
}
