package com.paytrack.app.notifications

import java.util.Calendar

/** Calendar-aware local-time calculations for investment reminders. */
object ReminderTimeCalculator {
    fun atTime(dateMillis: Long, hour: Int, minute: Int): Long = Calendar.getInstance().apply {
        timeInMillis = dateMillis
        set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
        set(Calendar.MINUTE, minute.coerceIn(0, 59))
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    fun daysBefore(dateMillis: Long, days: Int, hour: Int, minute: Int): Long =
        Calendar.getInstance().apply {
            timeInMillis = atTime(dateMillis, hour, minute)
            add(Calendar.DAY_OF_YEAR, -days)
        }.timeInMillis

    /** First pending reminder after the due date, or the next selected-time slot if already overdue. */
    fun firstPending(dueDateMillis: Long, nowMillis: Long, hour: Int, minute: Int): Long {
        val dayAfterDue = Calendar.getInstance().apply {
            timeInMillis = atTime(dueDateMillis, hour, minute)
            add(Calendar.DAY_OF_YEAR, 1)
        }.timeInMillis
        if (dayAfterDue > nowMillis) return dayAfterDue

        val nextSelectedTime = Calendar.getInstance().apply {
            timeInMillis = nowMillis
            set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
            set(Calendar.MINUTE, minute.coerceIn(0, 59))
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= nowMillis) add(Calendar.DAY_OF_YEAR, 1)
        }.timeInMillis
        return maxOf(dayAfterDue, nextSelectedTime)
    }

    fun nextDay(dateMillis: Long, hour: Int, minute: Int): Long = Calendar.getInstance().apply {
        timeInMillis = dateMillis
        add(Calendar.DAY_OF_YEAR, 1)
        set(Calendar.HOUR_OF_DAY, hour.coerceIn(0, 23))
        set(Calendar.MINUTE, minute.coerceIn(0, 59))
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis
}
