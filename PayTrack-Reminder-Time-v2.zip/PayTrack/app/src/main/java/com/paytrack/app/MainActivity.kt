package com.paytrack.app

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import androidx.room.Room
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.paytrack.app.data.*
import com.paytrack.app.notifications.ReminderScheduler
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

private val Navy = Color(0xFF08152F)
private val Panel = Color(0xFF112344)
private val Cobalt = Color(0xFF4169E1)
private val Pale = Color(0xFFEAF0FF)
private val Green = Color(0xFF55D6A2)
private val Muted = Color(0xFF9BAECC)

class MainActivity : ComponentActivity() {
    private lateinit var db: PayTrackDatabase
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = Room.databaseBuilder(applicationContext, PayTrackDatabase::class.java, "paytrack.db").addMigrations(PayTrackDatabase.MIGRATION_1_2, PayTrackDatabase.MIGRATION_2_3).build()
        setContent { PayTrackApp(db) }
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 501)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PayTrackApp(db: PayTrackDatabase) {
    val context = LocalContext.current
    val dao = db.dao()
    val scope = rememberCoroutineScope()
    val investments by dao.investments().collectAsState(initial = emptyList())
    val payments by dao.payments().collectAsState(initial = emptyList())
    val tasks by dao.tasks().collectAsState(initial = emptyList())
    var tab by remember { mutableIntStateOf(0) }
    var investmentDialog by remember { mutableStateOf(false) }
    var editingInvestment by remember { mutableStateOf<Investment?>(null) }
    var taskDialog by remember { mutableStateOf(false) }
    var editingTask by remember { mutableStateOf<TaskItem?>(null) }
    var showHistory by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }

    // Reconcile alarms whenever the app is opened; the boot receiver handles restarts.
    LaunchedEffect(investments, tasks) {
        investments.forEach { ReminderScheduler.scheduleInvestment(context, it) }
        tasks.filter { !it.completed }.forEach { ReminderScheduler.scheduleTask(context, it) }
    }

    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
        if (uri != null) scope.launch {
            val snapshot = BackupData(dao.allInvestments(), dao.allPayments(), dao.allTasks())
            context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(Gson().toJson(snapshot)) }
        }
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            runCatching {
                val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("Cannot read backup")
                val backupJson = com.google.gson.JsonParser.parseString(raw).asJsonObject
                backupJson.getAsJsonArray("investments")?.forEach { element ->
                    if (element.isJsonObject) {
                        val investment = element.asJsonObject
                        if (!investment.has("reminderHour")) investment.addProperty("reminderHour", 9)
                        if (!investment.has("reminderMinute")) investment.addProperty("reminderMinute", 0)
                    }
                }
                val data = Gson().fromJson(backupJson, BackupData::class.java)
                dao.clearInvestments(); dao.clearPayments(); dao.clearTasks()
                dao.insertInvestments(data.investments ?: emptyList()); dao.insertPayments(data.payments ?: emptyList()); dao.insertTasks(data.tasks ?: emptyList())
                (data.investments ?: emptyList()).forEach { ReminderScheduler.scheduleInvestment(context, it) }
                (data.tasks ?: emptyList()).filter { !it.completed }.forEach { ReminderScheduler.scheduleTask(context, it) }
            }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Cobalt, background = Navy, surface = Panel, onSurface = Pale, onBackground = Pale)) {
        Scaffold(containerColor = Navy, topBar = {
            TopAppBar(
                title = { Column { Text("PayTrack", fontWeight = FontWeight.Bold, color = Pale, fontSize = 21.sp); Text("Stay on top of every payment", color = Muted, fontSize = 11.sp) } },
                actions = {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, null, tint = Pale) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Payment history") }, onClick = { showHistory = true; menu = false })
                        DropdownMenuItem(text = { Text("Backup data") }, onClick = { backupLauncher.launch("paytrack-backup.json"); menu = false })
                        DropdownMenuItem(text = { Text("Restore backup") }, onClick = { restoreLauncher.launch(arrayOf("application/json", "text/*")); menu = false })
                        DropdownMenuItem(text = { Text("Notification settings") }, onClick = { context.startActivity(Intent("android.settings.APP_NOTIFICATION_SETTINGS").putExtra("android.provider.extra.APP_PACKAGE", context.packageName)); menu = false })
                        if (Build.VERSION.SDK_INT >= 31) DropdownMenuItem(text = { Text("Allow exact alarms") }, onClick = { context.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).setData(Uri.parse("package:${context.packageName}"))); menu = false })
                        DropdownMenuItem(text = { Text("Battery optimization settings") }, onClick = { context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); menu = false })
                    }
                }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy)
            )
        }, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Pale) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") }, colors = navColors())
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.CalendarMonth, null) }, label = { Text("Calendar") }, colors = navColors())
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.TaskAlt, null) }, label = { Text("To-Do") }, colors = navColors())
            }
        }, floatingActionButton = {
            if (tab != 1) FloatingActionButton(onClick = { if (tab == 0) { editingInvestment = null; investmentDialog = true } else { editingTask = null; taskDialog = true } }, containerColor = Cobalt, contentColor = Color.White) { Icon(Icons.Default.Add, "Add") }
        }) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (tab) {
                    0 -> HomeScreen(investments, tasks, payments, onAdd = { editingInvestment = null; investmentDialog = true }, onEdit = { editingInvestment = it; investmentDialog = true }, onPaid = { item ->
                        scope.launch {
                            dao.insertPayment(Payment(investmentId = item.id, investmentName = item.name, amount = item.amount, paidAt = System.currentTimeMillis(), dueAt = item.nextDue))
                            val next = nextDue(item.nextDue, item.frequency, item.customDays, item.anchorDay, item.anchorMonth)
                            dao.updateInvestment(item.copy(nextDue = next))
                            ReminderScheduler.scheduleInvestment(context, item.copy(nextDue = next))
                        }
                    }, onDelete = { item -> scope.launch { ReminderScheduler.cancelInvestment(context, item.id); dao.deleteInvestment(item) } })
                    1 -> CalendarScreen(investments, tasks)
                    else -> TodoScreen(tasks, onAdd = { editingTask = null; taskDialog = true }, onEdit = { editingTask = it; taskDialog = true }, onToggle = { item -> scope.launch { dao.updateTask(item.copy(completed = !item.completed)); if (!item.completed) ReminderScheduler.cancelTask(context, item.id) else ReminderScheduler.scheduleTask(context, item) } }, onDelete = { item -> scope.launch { ReminderScheduler.cancelTask(context, item.id); dao.deleteTask(item) } })
                }
            }
        }
    }
    if (investmentDialog) InvestmentEditor(editingInvestment, onDismiss = { investmentDialog = false }, onSave = { item ->
        scope.launch {
            val id = if (item.id == 0L) dao.insertInvestment(item) else { dao.updateInvestment(item); item.id }
            val saved = dao.investment(id)
            if (saved != null) ReminderScheduler.scheduleInvestment(context, saved)
            investmentDialog = false
        }
    })
    if (taskDialog) TaskEditor(editingTask, onDismiss = { taskDialog = false }, onSave = { item ->
        scope.launch {
            val id = if (item.id == 0L) dao.insertTask(item) else { dao.updateTask(item); item.id }
            val saved = tasks.firstOrNull { it.id == id } ?: item.copy(id = id)
            ReminderScheduler.scheduleTask(context, saved)
            taskDialog = false
        }
    })
    if (showHistory) AlertDialog(onDismissRequest = { showHistory = false }, title = { Text("Payment history") }, text = {
        LazyColumn(Modifier.heightIn(max = 420.dp)) { items(payments) { p -> Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) { Text(p.investmentName, fontWeight = FontWeight.SemiBold); Text("${rupees(p.amount)} · Paid ${date(p.paidAt)}", color = Muted, fontSize = 12.sp) }; Divider(color = Muted.copy(alpha = .2f)) } }
    }, confirmButton = { TextButton(onClick = { showHistory = false }) { Text("Close") } })
}

@Composable private fun navColors() = NavigationBarItemDefaults.colors(selectedIconColor = Pale, selectedTextColor = Pale, indicatorColor = Cobalt, unselectedIconColor = Muted, unselectedTextColor = Muted)

@Composable
fun HomeScreen(investments: List<Investment>, tasks: List<TaskItem>, payments: List<Payment>, onAdd: () -> Unit, onEdit: (Investment) -> Unit, onPaid: (Investment) -> Unit, onDelete: (Investment) -> Unit) {
    val now = Calendar.getInstance()
    val monthStart = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
    val monthEnd = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH)); set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59) }.timeInMillis
    val upcoming = investments.sortedBy { it.nextDue }
    val monthAmount = upcoming.filter { it.nextDue in monthStart..monthEnd }.sumOf { it.amount }
    val pending = upcoming.filter { it.nextDue < dayEnd(System.currentTimeMillis()) }
    val todayTasks = tasks.filter { !it.completed && it.deadline <= dayEnd(System.currentTimeMillis()) }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), contentPadding = PaddingValues(top = 14.dp, bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Upcoming", upcoming.size.toString(), Modifier.weight(1f))
                MetricCard("Due this month", rupees(monthAmount), Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricCard("Pending", pending.size.toString(), Modifier.weight(1f), accent = Color(0xFFFFB86B))
                MetricCard("Today's tasks", todayTasks.size.toString(), Modifier.weight(1f), accent = Green)
            }
        }
        item { SectionTitle("Next payment", "Your next scheduled contribution") }
        if (upcoming.isNotEmpty()) item {
            val next = upcoming.first()
            Card(colors = CardDefaults.cardColors(containerColor = Cobalt), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text(next.name, color = Color.White.copy(alpha = .8f), fontSize = 13.sp)
                    Text(rupees(next.amount), color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Bold)
                    Text("Due ${date(next.nextDue)}", color = Color.White.copy(alpha = .85f))
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { onPaid(next) }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Navy)) { Icon(Icons.Default.CheckCircle, null); Spacer(Modifier.width(6.dp)); Text("Mark as Paid") }
                }
            }
        } else item { EmptyCard("No investments yet", "Add your first recurring payment to get started.", onAdd) }
        item { SectionTitle("Upcoming payments", "Manage your recurring investments") }
        items(upcoming, key = { it.id }) { item -> InvestmentCard(item, onPaid, onEdit, onDelete) }
        if (upcoming.isEmpty()) item { EmptyCard("Nothing scheduled", "Your upcoming payments will appear here.", onAdd) }
        item { SectionTitle("Today's tasks", "Deadlines that need your attention") }
        if (todayTasks.isEmpty()) item { Text("You're all caught up.", color = Muted, modifier = Modifier.padding(vertical = 8.dp)) }
        items(todayTasks, key = { "task${it.id}" }) { Text("•  ${it.title}  ·  ${date(it.deadline)}", color = Pale, modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(14.dp)) }
    }
}

@Composable fun MetricCard(label: String, value: String, modifier: Modifier = Modifier, accent: Color = Pale) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) { Column(Modifier.padding(15.dp)) { Text(label, color = Muted, fontSize = 12.sp); Spacer(Modifier.height(7.dp)); Text(value, color = accent, fontSize = 20.sp, fontWeight = FontWeight.Bold) } }
}
@Composable fun SectionTitle(title: String, subtitle: String) { Column { Text(title, color = Pale, fontSize = 17.sp, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, fontSize = 11.sp) } }
@Composable fun EmptyCard(title: String, subtitle: String, action: () -> Unit) { Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) { Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(title, color = Pale, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Muted, fontSize = 12.sp); TextButton(onClick = action) { Text("Add now") } } } }

@Composable
fun InvestmentCard(item: Investment, onPaid: (Investment) -> Unit, onEdit: (Investment) -> Unit, onDelete: (Investment) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(15.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(item.name, color = Pale, fontWeight = FontWeight.SemiBold); Text("${frequencyLabel(item.frequency)} · Due ${date(item.nextDue)}", color = Muted, fontSize = 11.sp) }
                Text(rupees(item.amount), color = Pale, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Box { IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, null, tint = Muted) }; DropdownMenu(menu, { menu = false }) { DropdownMenuItem(text = { Text("Edit") }, onClick = { menu = false; onEdit(item) }); DropdownMenuItem(text = { Text("Delete") }, onClick = { menu = false; onDelete(item) }) } }
            }
            Spacer(Modifier.height(10.dp))
            Button(onClick = { onPaid(item) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Cobalt), shape = RoundedCornerShape(11.dp)) { Icon(Icons.Default.CheckCircle, null); Spacer(Modifier.width(7.dp)); Text("Mark as Paid") }
        }
    }
}

@Composable
fun CalendarScreen(investments: List<Investment>, tasks: List<TaskItem>) {
    var month by remember { mutableStateOf(Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1) }) }
    var selected by remember { mutableLongStateOf(dayStart(System.currentTimeMillis())) }
    val days = month.getActualMaximum(Calendar.DAY_OF_MONTH)
    val offset = (month.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY)
    val monthStart = month.timeInMillis
    val monthEnd = (month.clone() as Calendar).apply { add(Calendar.MONTH, 1); add(Calendar.MILLISECOND, -1) }.timeInMillis
    val occurrences = investments.flatMap { item -> investmentOccurrences(item, monthStart, monthEnd) }
    val selectedItems = occurrences.filter { dayStart(it.second) == selected }
    val selectedTasks = tasks.filter { dayStart(it.deadline) == selected }
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text(SimpleDateFormat("MMMM yyyy", Locale.ENGLISH).format(month.time), color = Pale, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Row { TextButton(onClick = { month = (month.clone() as Calendar).apply { add(Calendar.MONTH, -1) } }) { Text("‹", fontSize = 24.sp) }; TextButton(onClick = { month = (month.clone() as Calendar).apply { add(Calendar.MONTH, 1) } }) { Text("›", fontSize = 24.sp) } }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { listOf("S", "M", "T", "W", "T", "F", "S").forEach { Text(it, color = Muted, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center) } }
        Spacer(Modifier.height(8.dp))
        for (week in 0..5) {
            Row(Modifier.fillMaxWidth()) {
                for (dow in 0..6) {
                    val day = week * 7 + dow - offset + 1
                    Box(Modifier.weight(1f).aspectRatio(1f).padding(2.dp).background(if (day in 1..days && dayStart(month.timeInMillis + (day - 1) * ReminderScheduler.DAY) == selected) Cobalt else Color.Transparent, CircleShape).clickable(enabled = day in 1..days) { selected = dayStart(month.timeInMillis + (day - 1) * ReminderScheduler.DAY) }, contentAlignment = Alignment.Center) {
                        if (day in 1..days) {
                            val dateMs = month.timeInMillis + (day - 1) * ReminderScheduler.DAY
                            val hasInv = occurrences.any { dayStart(it.second) == dayStart(dateMs) }
                            val hasTask = tasks.any { dayStart(it.deadline) == dayStart(dateMs) }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(day.toString(), color = if (dayStart(dateMs) == dayStart(System.currentTimeMillis())) Green else Pale, fontSize = 13.sp); Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) { if (hasInv) Box(Modifier.size(5.dp).background(Cobalt, CircleShape)); if (hasTask) Box(Modifier.size(5.dp).background(Green, CircleShape)) } }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(15.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) { Legend(Cobalt, "Investments"); Legend(Green, "Tasks") }
        Spacer(Modifier.height(18.dp))
        Text(date(selected), color = Pale, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Spacer(Modifier.height(8.dp))
        if (selectedItems.isEmpty() && selectedTasks.isEmpty()) Text("Nothing scheduled for this day.", color = Muted)
        selectedItems.forEach { (item, dueAt) -> Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Panel, RoundedCornerShape(10.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(8.dp).background(Cobalt, CircleShape)); Spacer(Modifier.width(9.dp)); Text("${item.name} · ${rupees(item.amount)}", color = Pale) } }
        selectedTasks.forEach { Row(Modifier.fillMaxWidth().padding(vertical = 5.dp).background(Panel, RoundedCornerShape(10.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(8.dp).background(Green, CircleShape)); Spacer(Modifier.width(9.dp)); Text(it.title, color = Pale) } }
    }
}
@Composable fun Legend(color: Color, label: String) { Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(8.dp).background(color, CircleShape)); Spacer(Modifier.width(5.dp)); Text(label, color = Muted, fontSize = 11.sp) } }

@Composable
fun TodoScreen(tasks: List<TaskItem>, onAdd: () -> Unit, onEdit: (TaskItem) -> Unit, onToggle: (TaskItem) -> Unit, onDelete: (TaskItem) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(18.dp)); SectionTitle("Your to-do list", "Keep important tasks and deadlines in one place")
        Spacer(Modifier.height(12.dp))
        if (tasks.isEmpty()) EmptyCard("No tasks yet", "Add a task and set a deadline.", onAdd)
        LazyColumn(contentPadding = PaddingValues(bottom = 90.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            items(tasks, key = { it.id }) { task ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = task.completed, onCheckedChange = { onToggle(task) }, colors = CheckboxDefaults.colors(checkedColor = Green, uncheckedColor = Muted))
                        Column(Modifier.weight(1f).clickable { onEdit(task) }) { Text(task.title, color = if (task.completed) Muted else Pale, fontWeight = FontWeight.SemiBold); Text("Due ${date(task.deadline)}", color = Muted, fontSize = 11.sp) }
                        IconButton(onClick = { onEdit(task) }) { Icon(Icons.Default.Edit, null, tint = Muted) }
                        IconButton(onClick = { onDelete(task) }) { Icon(Icons.Default.Delete, null, tint = Muted) }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InvestmentEditor(existing: Investment?, onDismiss: () -> Unit, onSave: (Investment) -> Unit) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var amount by remember { mutableStateOf(existing?.amount?.toString() ?: "") }
    var frequency by remember { mutableStateOf(existing?.frequency ?: "Monthly") }
    var due by remember { mutableLongStateOf(existing?.nextDue ?: dayAtNine(System.currentTimeMillis() + ReminderScheduler.DAY)) }
    var reminderHour by remember { mutableIntStateOf(existing?.reminderHour ?: 9) }
    var reminderMinute by remember { mutableIntStateOf(existing?.reminderMinute ?: 0) }
    var custom by remember { mutableStateOf(existing?.customDays?.toString() ?: "30") }
    var expanded by remember { mutableStateOf(false) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null) "Add investment" else "Edit investment") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Investment name") }, singleLine = true)
            OutlinedTextField(amount, { amount = it.filter(Char::isDigit) }, label = { Text("Amount (₹)") }, singleLine = true)
            ExposedDropdownMenuBox(expanded, { expanded = !expanded }) { OutlinedTextField(frequency, {}, readOnly = true, label = { Text("Frequency") }, modifier = Modifier.menuAnchor()); ExposedDropdownMenu(expanded, { expanded = false }) { listOf("Monthly", "Quarterly", "Half-Yearly", "Yearly", "Custom").forEach { DropdownMenuItem(text = { Text(it) }, onClick = { frequency = it; expanded = false }) } } }
            if (frequency == "Custom") OutlinedTextField(custom, { custom = it.filter(Char::isDigit) }, label = { Text("Repeat every (days)") }, singleLine = true)
            DateButton("Next payment date", due) { due = it }
            TimeButton("Reminder time", reminderHour, reminderMinute) { hour, minute ->
                reminderHour = hour
                reminderMinute = minute
            }
            Text("Reminders: 2 days before, on the due date, then daily if unpaid.", color = Muted, fontSize = 11.sp)
        }
    }, confirmButton = { TextButton(enabled = name.isNotBlank() && amount.toLongOrNull() != null && amount.toLong() > 0 && (frequency != "Custom" || (custom.toIntOrNull() ?: 0) > 0), onClick = { onSave(Investment(id = existing?.id ?: 0, name = name.trim(), amount = amount.toLong(), frequency = frequency, nextDue = due, customDays = custom.toIntOrNull() ?: 30, anchorDay = Calendar.getInstance().apply { timeInMillis = due }.get(Calendar.DAY_OF_MONTH), anchorMonth = Calendar.getInstance().apply { timeInMillis = due }.get(Calendar.MONTH), reminderHour = reminderHour, reminderMinute = reminderMinute)) }) { Text("Save") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
fun TaskEditor(existing: TaskItem?, onDismiss: () -> Unit, onSave: (TaskItem) -> Unit) {
    var title by remember { mutableStateOf(existing?.title ?: "") }
    var deadline by remember { mutableLongStateOf(existing?.deadline ?: dayAtNine(System.currentTimeMillis() + ReminderScheduler.DAY)) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null) "Add task" else "Edit task") }, text = { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) { OutlinedTextField(title, { title = it }, label = { Text("Task") }, singleLine = true); DateButton("Deadline", deadline) { deadline = it } } }, confirmButton = { TextButton(enabled = title.isNotBlank(), onClick = { onSave(TaskItem(id = existing?.id ?: 0, title = title.trim(), deadline = deadline, completed = existing?.completed ?: false)) }) { Text("Save") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } })
}

@Composable
fun TimeButton(label: String, hour: Int, minute: Int, onPick: (Int, Int) -> Unit) {
    val context = LocalContext.current
    val formatted = SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, hour)
        set(Calendar.MINUTE, minute)
    }.time)
    OutlinedButton(onClick = {
        TimePickerDialog(context, { _, selectedHour, selectedMinute ->
            onPick(selectedHour, selectedMinute)
        }, hour, minute, false).show()
    }, modifier = Modifier.fillMaxWidth()) {
        Text("$label: $formatted")
    }
}

@Composable
fun DateButton(label: String, value: Long, onPick: (Long) -> Unit) {
    val context = LocalContext.current
    OutlinedButton(onClick = {
        val c = Calendar.getInstance().apply { timeInMillis = value }
        DatePickerDialog(context, { _, y, m, d -> val picked = Calendar.getInstance().apply { set(y, m, d, 9, 0, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis; onPick(picked) }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    }, modifier = Modifier.fillMaxWidth()) { Text("$label: ${date(value)}") }
}

private data class BackupData(val investments: List<Investment>?, val payments: List<Payment>?, val tasks: List<TaskItem>?)
private fun rupees(value: Long): String = NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply { maximumFractionDigits = 0; minimumFractionDigits = 0 }.format(value)
private fun date(value: Long): String = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH).format(Date(value))
private fun dayAtNine(value: Long): Long = Calendar.getInstance().apply { timeInMillis = value; set(Calendar.HOUR_OF_DAY, 9); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
private fun dayStart(value: Long): Long = Calendar.getInstance().apply { timeInMillis = value; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
private fun dayEnd(value: Long): Long = dayStart(value) + ReminderScheduler.DAY - 1
private fun advanceDue(from: Long, frequency: String, customDays: Int, anchorDay: Int = 0, anchorMonth: Int = -1): Long =
    RecurrenceCalculator.advanceDue(from, frequency, customDays, anchorDay, anchorMonth)
private fun nextDue(from: Long, frequency: String, customDays: Int, anchorDay: Int = 0, anchorMonth: Int = -1): Long =
    RecurrenceCalculator.nextDue(from, frequency, customDays, System.currentTimeMillis(), anchorDay, anchorMonth)
private fun investmentOccurrences(item: Investment, start: Long, end: Long): List<Pair<Investment, Long>> {
    val result = mutableListOf<Pair<Investment, Long>>()
    var due = item.nextDue
    var guard = 0
    while (due < start && guard++ < 600) due = advanceDue(due, item.frequency, item.customDays, item.anchorDay, item.anchorMonth)
    while (due <= end && guard++ < 620) { if (due >= start) result += item to due; due = advanceDue(due, item.frequency, item.customDays, item.anchorDay, item.anchorMonth) }
    return result
}
private fun frequencyLabel(value: String) = if (value == "Custom") "Custom interval" else value
