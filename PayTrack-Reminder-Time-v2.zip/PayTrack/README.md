# PayTrack – Investment Reminder

A local-first Android app for manually tracking recurring investment contributions and task deadlines. No login, payment processing, internet permission, ads, or subscription SDKs are included.

## Features in this project

- Investments: add, edit, delete; monthly, quarterly, half-yearly, yearly, or custom-day recurrence.
- Manual payment completion, payment timestamp/history, and automatic next-due calculation.
- Local Android alarms: choose a reminder time per investment (default 9:00 AM), with a 2-day warning, due-day alert, then daily pending reminders at the same selected time until marked paid.
- To-do tasks with deadlines, completion state, and a one-day-before local reminder.
- Monthly calendar with investment and task markers; recurring investment dates are projected across the displayed month.
- Home dashboard with upcoming count, current-month amount, next payment, pending count, and today's/overdue tasks.
- Local Room database and JSON backup/restore.
- Deep navy / cobalt dark UI.

## Build from an Android phone (cloud build)

This repository includes `.github/workflows/android.yml`. Once the project is committed to a GitHub repository, GitHub Actions can build the APK in the cloud; Android Studio is not required on the phone. The workflow installs JDK 17, Android SDK Platform 35, Gradle 8.9, runs unit tests, and uploads `app-debug.apk` as the `PayTrack-debug-apk` artifact. Open the repository's **Actions** tab, select **Build PayTrack APK**, run the workflow (or push to `main`), open the successful run, and download the artifact. Extract the artifact ZIP to get `app-debug.apk`, then open it on Android and allow installation from that source.

A GitHub account/repository is required for this free cloud-build route. The APK produced is a debug-signed APK suitable for personal installation and testing; it is not a Play Store release.

## V2 reminder-time update

- Each investment now has its own reminder time, defaulting to 9:00 AM. Use Edit on an investment to change it.
- The selected time is used for the 2-days-before alert, due-day alert, and daily overdue reminders. Editing and saving reschedules the alarms.
- Database schema version 3 migrates existing v2 records by assigning 9:00 AM. Old JSON backups are also imported with a 9:00 AM default when reminder-time fields are absent.
- This V2 build uses application ID `com.paytrack.app.v2`, so it installs as a separate app and leaves the original `com.paytrack.app` installation and its data untouched. Export a JSON backup from the original app and restore it in V2 if you want to copy your investments.

## Build in Android Studio

1. Install Android Studio (current stable) with Android SDK Platform 35.
2. Open this `PayTrack` folder as an existing Gradle project.
3. Allow Gradle sync to download the Android Gradle Plugin, Kotlin, Compose, Room, and Gson dependencies.
4. Build > Build Bundle(s) / APK(s) > Build APK(s), then install the generated debug APK on your phone.

Package: `com.paytrack.app.v2` · Version: 2.0.0 · Minimum Android: 8.0 (API 26) · Target SDK: 35. This V2 package installs alongside the original PayTrack app and does not overwrite it.

## Notification setup and reliability notes

- Android 13+ asks for notification permission on first launch.
- On Android 12+, open the app menu and choose **Allow exact alarms**. If exact-alarm access is not granted, the app uses Android's inexact idle-allowed alarm fallback, which can be delayed by the OS.
- The app reschedules alarms after device reboot and app replacement. Some manufacturers apply aggressive battery restrictions; if reminders are delayed, allow PayTrack background activity / disable battery optimization in system settings.
- Android may delay alarms in Doze or after force-stop. No third-party app can guarantee exact delivery if the user force-stops the app, disables notifications, revokes alarm access, or the device is powered off.
- Data is stored locally. Use **Backup data** periodically and keep the JSON file somewhere safe. Restore replaces the app's current local records.

## Implementation notes

- Room database: `paytrack.db` (schema version 3; automatic migrations preserve existing investments and add reminder-time fields).
- AlarmManager + BroadcastReceiver for local notifications; `BOOT_COMPLETED` receiver rebuilds schedules.
- Amounts are stored as whole INR rupees (no paise / fractional amounts).
- This source project has not yet been built or tested on a physical Android device in this environment because Android SDK / Gradle build tooling and a connected device are unavailable. The included GitHub Actions workflow is a reproducible cloud-build path, not evidence that a build or device test has already passed. Before relying on reminders, verify notification permission, exact-alarm access, due/pending schedules, reboot restoration, backup/restore, and date edge cases on the target phone.

## Mobile-only GitHub upload route

If uploading the extracted project folder from Android is inconvenient, upload `PayTrack-Android-Studio-Project.zip` to the root of a new GitHub repository. Then create `.github/workflows/build.yml` in that repository and paste the contents of the separately supplied `PayTrack-Mobile-Cloud-Build-Workflow.yml`. Commit both files. The workflow extracts the project, runs the JVM tests, builds the APK, runs the Android instrumentation suite on an API 35 emulator, and uploads the debug APK artifact. A green workflow run is required before treating the cloud build and emulator tests as passed.

## Automated test coverage

- JVM recurrence tests cover monthly 31st-day clamping/recovery, quarterly, half-yearly, leap-year yearly schedules, custom-day intervals, and skipping elapsed periods.
- Android instrumentation tests cover Room persistence across close/reopen, registration/cancellation of all three investment alarm slots, actual scheduled-alarm delivery of a local due notification through the receiver, and the same database-to-alarm rescheduling routine used by the boot receiver.
- These Android instrumentation tests are configured in the GitHub Actions workflow to run on an API 35 emulator. They remain **pending** until that workflow completes successfully; they have not been executed in this offline build environment.
