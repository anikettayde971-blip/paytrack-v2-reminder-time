package com.paytrack.app

import android.content.Context
import android.app.NotificationManager
import android.Manifest
import android.os.Build
import androidx.room.Room
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import com.paytrack.app.data.Expense
import com.paytrack.app.data.Investment
import com.paytrack.app.data.PayTrackDatabase
import com.paytrack.app.data.TaskItem
import com.paytrack.app.notifications.ReminderScheduler
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.util.Calendar

@RunWith(AndroidJUnit4::class)
class PayTrackReliabilityTest {
    private lateinit var context: Context
    private var testTaskId: Long? = null

    @Before fun setUp() {
        context = InstrumentationRegistry.getInstrumentation().targetContext
        context.deleteDatabase("paytrack.db")
    }

    @After fun tearDown() {
        ReminderScheduler.cancelInvestment(context, TEST_ID)
        testTaskId?.let { ReminderScheduler.cancelTask(context, it) }
        context.deleteDatabase("paytrack.db")
    }

    @Test fun roomDataSurvivesDatabaseCloseAndReopen() = runBlocking {
        var db = Room.databaseBuilder(context, PayTrackDatabase::class.java, "paytrack.db")
            .addMigrations(PayTrackDatabase.MIGRATION_1_2, PayTrackDatabase.MIGRATION_2_3, PayTrackDatabase.MIGRATION_3_4).build()
        val id = db.dao().insertInvestment(Investment(
            name = "NPS Fund", amount = 3900, frequency = "Monthly",
            nextDue = futureDate(3), anchorDay = 12, anchorMonth = 10, reminderHour = 18, reminderMinute = 45
        ))
        val expenseId = db.dao().insertExpense(Expense(amount = 250, category = "Food", spentAt = futureDate(0), note = "Lunch"))
        db.close()

        db = Room.databaseBuilder(context, PayTrackDatabase::class.java, "paytrack.db")
            .addMigrations(PayTrackDatabase.MIGRATION_1_2, PayTrackDatabase.MIGRATION_2_3, PayTrackDatabase.MIGRATION_3_4).build()
        val restored = db.dao().investment(id)
        assertEquals("NPS Fund", restored?.name)
        assertEquals(3900L, restored?.amount ?: -1L)
        assertEquals(12, restored?.anchorDay ?: -1)
        assertEquals(18, restored?.reminderHour ?: -1)
        assertEquals(45, restored?.reminderMinute ?: -1)
        val savedExpense = db.dao().allExpenses().firstOrNull { it.id == expenseId }
        assertEquals("Food", savedExpense?.category)
        assertEquals(250L, savedExpense?.amount ?: -1L)
        assertEquals("Lunch", savedExpense?.note)
        db.close()
    }

    @Test fun investmentAlarmSlotsAreRegisteredAndCancelled() {
        val investment = Investment(
            id = TEST_ID, name = "NPS Fund", amount = 3900, frequency = "Monthly",
            nextDue = futureDate(3), anchorDay = 12, anchorMonth = 10
        )
        ReminderScheduler.scheduleInvestment(context, investment)
        assertTrue(ReminderScheduler.hasInvestmentAlarm(context, TEST_ID, 0)) // two days before
        assertTrue(ReminderScheduler.hasInvestmentAlarm(context, TEST_ID, 1)) // due date
        assertTrue(ReminderScheduler.hasInvestmentAlarm(context, TEST_ID, 2)) // pending follow-up

        ReminderScheduler.cancelInvestment(context, TEST_ID)
        assertFalse(ReminderScheduler.hasInvestmentAlarm(context, TEST_ID, 0))
        assertFalse(ReminderScheduler.hasInvestmentAlarm(context, TEST_ID, 1))
        assertFalse(ReminderScheduler.hasInvestmentAlarm(context, TEST_ID, 2))
    }


    @Test fun scheduledAlarmDeliversLocalDueNotification() = runBlocking {
        if (Build.VERSION.SDK_INT >= 33) {
            InstrumentationRegistry.getInstrumentation().uiAutomation
                .grantRuntimePermission(context.packageName, Manifest.permission.POST_NOTIFICATIONS)
        }
        if (Build.VERSION.SDK_INT >= 31) {
            val command = "cmd appops set ${context.packageName} SCHEDULE_EXACT_ALARM allow"
            InstrumentationRegistry.getInstrumentation().uiAutomation.executeShellCommand(command).close()
        }
        val dueAt = System.currentTimeMillis() + 5_000
        val db = Room.databaseBuilder(context, PayTrackDatabase::class.java, "paytrack.db")
            .addMigrations(PayTrackDatabase.MIGRATION_1_2, PayTrackDatabase.MIGRATION_2_3, PayTrackDatabase.MIGRATION_3_4).build()
        db.dao().insertInvestment(Investment(
            id = TEST_ID, name = "NPS Fund", amount = 3900, frequency = "Monthly",
            nextDue = dueAt, anchorDay = 12, anchorMonth = 10
        ))
        db.close()

        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notificationId = (TEST_ID * 10 + "due".hashCode()).toInt()
        notificationManager.cancel(notificationId)
        ReminderScheduler.scheduleInvestment(context, Investment(
            id = TEST_ID, name = "NPS Fund", amount = 3900, frequency = "Monthly",
            nextDue = dueAt, anchorDay = 12, anchorMonth = 10
        ))

        val deadline = System.currentTimeMillis() + 20_000
        var posted = notificationManager.activeNotifications.firstOrNull { it.id == notificationId }
        while (posted == null && System.currentTimeMillis() < deadline) {
            Thread.sleep(100)
            posted = notificationManager.activeNotifications.firstOrNull { it.id == notificationId }
        }
        assertTrue("Due notification was not posted", posted != null)
        val text = posted?.notification?.extras?.getCharSequence(android.app.Notification.EXTRA_TEXT)?.toString().orEmpty()
        assertTrue(text.contains("NPS Fund"))
        notificationManager.cancel(notificationId)
    }

    @Test fun rebootReschedulerRestoresInvestmentAndTaskAlarms() = runBlocking {
        val db = Room.databaseBuilder(context, PayTrackDatabase::class.java, "paytrack.db")
            .addMigrations(PayTrackDatabase.MIGRATION_1_2, PayTrackDatabase.MIGRATION_2_3, PayTrackDatabase.MIGRATION_3_4).build()
        db.dao().insertInvestment(Investment(
            id = TEST_ID, name = "NPS Fund", amount = 3900, frequency = "Monthly",
            nextDue = futureDate(3), anchorDay = 12, anchorMonth = 10
        ))
        val taskId = db.dao().insertTask(TaskItem(title = "Submit form", deadline = futureDate(2)))
        testTaskId = taskId
        db.close()

        // This is the same rescheduling path invoked by BOOT_COMPLETED.
        ReminderScheduler.rescheduleAll(context)
        assertTrue(ReminderScheduler.hasInvestmentAlarm(context, TEST_ID, 0))
        assertTrue(ReminderScheduler.hasInvestmentAlarm(context, TEST_ID, 1))
        assertTrue(ReminderScheduler.hasInvestmentAlarm(context, TEST_ID, 2))
        assertTrue(ReminderScheduler.hasTaskAlarm(context, taskId))
    }

    private fun futureDate(days: Int): Long = Calendar.getInstance().apply {
        add(Calendar.DAY_OF_YEAR, days)
        set(Calendar.HOUR_OF_DAY, 9)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    companion object { private const val TEST_ID = 424242L }
}
