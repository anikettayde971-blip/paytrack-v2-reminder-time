package com.paytrack.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Entity(tableName = "investments")
data class Investment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val amount: Long,
    val frequency: String,
    val nextDue: Long,
    val customDays: Int = 30,
    val active: Boolean = true,
    val anchorDay: Int = 0,
    val anchorMonth: Int = -1,
    val reminderHour: Int = 9,
    val reminderMinute: Int = 0
)

@Entity(tableName = "payments")
data class Payment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val investmentId: Long,
    val investmentName: String,
    val amount: Long,
    val paidAt: Long,
    val dueAt: Long
)

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amount: Long,
    val category: String,
    val spentAt: Long,
    val note: String = ""
)

@Entity(tableName = "tasks")
data class TaskItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val deadline: Long,
    val completed: Boolean = false
)

@Dao interface PayTrackDao {
    @Query("SELECT * FROM investments WHERE active = 1 ORDER BY nextDue") fun investments(): Flow<List<Investment>>
    @Query("SELECT * FROM investments WHERE id = :id") suspend fun investment(id: Long): Investment?
    @Insert suspend fun insertInvestment(item: Investment): Long
    @Update suspend fun updateInvestment(item: Investment)
    @Delete suspend fun deleteInvestment(item: Investment)
    @Query("SELECT * FROM payments ORDER BY paidAt DESC") fun payments(): Flow<List<Payment>>
    @Insert suspend fun insertPayment(item: Payment)
    @Query("SELECT * FROM tasks ORDER BY deadline") fun tasks(): Flow<List<TaskItem>>
    @Query("SELECT * FROM expenses ORDER BY spentAt DESC") fun expenses(): Flow<List<Expense>>
    @Insert suspend fun insertExpense(item: Expense): Long
    @Update suspend fun updateExpense(item: Expense)
    @Delete suspend fun deleteExpense(item: Expense)
    @Query("SELECT * FROM expenses") suspend fun allExpenses(): List<Expense>
    @Query("DELETE FROM expenses") suspend fun clearExpenses()
    @Insert suspend fun insertExpenses(items: List<Expense>)
    @Insert suspend fun insertTask(item: TaskItem): Long
    @Update suspend fun updateTask(item: TaskItem)
    @Delete suspend fun deleteTask(item: TaskItem)
    @Query("SELECT * FROM investments") suspend fun allInvestments(): List<Investment>
    @Query("SELECT * FROM payments") suspend fun allPayments(): List<Payment>
    @Query("SELECT * FROM tasks") suspend fun allTasks(): List<TaskItem>
    @Query("DELETE FROM investments") suspend fun clearInvestments()
    @Query("DELETE FROM payments") suspend fun clearPayments()
    @Query("DELETE FROM tasks") suspend fun clearTasks()
    @Insert suspend fun insertInvestments(items: List<Investment>)
    @Insert suspend fun insertPayments(items: List<Payment>)
    @Insert suspend fun insertTasks(items: List<TaskItem>)
}

@Database(entities = [Investment::class, Payment::class, TaskItem::class, Expense::class], version = 4, exportSchema = false)
abstract class PayTrackDatabase : RoomDatabase() {
    abstract fun dao(): PayTrackDao

    companion object {
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE investments ADD COLUMN anchorDay INTEGER NOT NULL DEFAULT 0")
                database.execSQL("ALTER TABLE investments ADD COLUMN anchorMonth INTEGER NOT NULL DEFAULT -1")
            }
        }
        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("CREATE TABLE IF NOT EXISTS expenses (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, amount INTEGER NOT NULL, category TEXT NOT NULL, spentAt INTEGER NOT NULL, note TEXT NOT NULL)")
            }
        }
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE investments ADD COLUMN reminderHour INTEGER NOT NULL DEFAULT 9")
                database.execSQL("ALTER TABLE investments ADD COLUMN reminderMinute INTEGER NOT NULL DEFAULT 0")
            }
        }
    }
}
